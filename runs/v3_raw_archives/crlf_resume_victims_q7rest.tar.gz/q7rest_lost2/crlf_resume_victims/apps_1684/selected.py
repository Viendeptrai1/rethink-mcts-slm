from collections import defaultdict

def check_symmetry(n, m, segments):
    # Create adjacency list
    adj = defaultdict(list)
    for a, b in segments:
        adj[a].append(b)
        adj[b].append(a)

    # Check all possible rotations
    for k in range(1, n):
        valid = True
        for a in range(1, n+1):
            next_a = (a + k - 1) % n + 1
            if len(adj[a]) != len(adj[next_a]):
                valid = False
                break
            for b in adj[a]:
                next_b = (b + k - 1) % n + 1
                if next_b not in adj[next_a]:
                    valid = False
                    break
            if not valid:
                break
        if valid:
            return "Yes"
    return "No"

# Read input
n, m = map(int, input().split())
segments = [tuple(map(int, input().split())) for _ in range(m)]

# Output result
print(check_symmetry(n, m, segments))